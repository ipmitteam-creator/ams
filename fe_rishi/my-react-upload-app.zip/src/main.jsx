
import React from 'react'
import ReactDOM from 'react-dom/client'
import UploadPhoto from './UploadPhoto'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <UploadPhoto />
  </React.StrictMode>
)
